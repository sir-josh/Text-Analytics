<html lang="en-US">
  <head>
      <meta charset="utf-8" />
      <meta http-equiv="Content-type" content="text/html; charset=utf-8" />
      <title>Text Analytics</title>
      <meta name="description" content="" />
      <!-- mobile settings -->
      <meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=0" />

      <!-- WEB FONTS -->
      <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700,800&amp;subset=latin,latin-ext,cyrillic,cyrillic-ext" rel="stylesheet" type="text/css" />

      <!-- CORE CSS -->
      <link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
      
      <!-- THEME CSS -->
      <link href="assets/css/main.css" rel="stylesheet" type="text/css" />
      <link href="assets/css/essentials.css" rel="stylesheet" type="text/css" />
      <link href="assets/css/layout.css" rel="stylesheet" type="text/css" />
      <link href="assets/css/color_scheme/green.css" rel="stylesheet" type="text/css" id="color_scheme" />

  </head>
  <!--   .boxed = boxed version  -->

  <body>
    <!--Main holder starts here-->
    <div class="mainbody">

      <!--Form holder starts here-->
      <div class="formholder">

        <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="POST" role="form" style="margin-top:10%">
          <legend style="font-size:200%;">Generate your Chart...</legend>
        
          <div class="form-group">
            <div>
            <label for="comment" style="font-weight:bold;">Comment: </label>
            </div>
            <textarea name="text" class="col-xs-9 col-xs-offset-1" class="form-control" rows="12"  id="comment" placeholder="Enter text here" ></textarea>
          </div>
        
            <button type="submit" class="btn btn-info col-xs-9 col-xs-offset-1" style="margin-top:5%;" name="submit" value="Post"><i class="fa fa-check-circle"></i> &nbsp Submit</button>
        </form>

      </div><!--Form holder ends here-->

      <!--Functions that processes the text starts here-->
      <?php     
      //This function returns the number of letter in a string or text
        function get_num_of_Letters($text)
        {
          $letters = strlen(preg_replace('/[^A-Za-z]/', '', $text));
          return $letters;            
        }
      //This function returns the number of words in a string or text
        function get_num_of_words($text)
        {
          $words = str_word_count($text);     
          return $words;
        }
       // This function returns the number of symbols in a text
        function get_num_of_symbols($text)
        {
          preg_match_all("/[^a-zA-Z0-9 ]+/i", $text, $output);
              $num = count($output[0]);
          return $num;
        }
      // This function returns the number of letters that appear 3 or more times...
        function get_three_OrMore_Letters($text)
        {
          $nword = strtolower($text);
          $str_length = strlen($nword);
          $str_array = count_chars($nword, 1);
          $array_len = count($str_array);
          $newArray = array_values($str_array);
          unset($newArray[0]);
          $workArray = array_values($newArray);
          $count=0;
          foreach ($workArray as $key => $value)
          {
            if ($value >=3)
            {
              $count++;
            }
          }
          return $count;
        }
      //This function returns the number of word(s) used once in a text
        function num_of_words_usedOnce($text)
        {
                $nword = strtolower($text);
                $output = $words = array();
                $counter = 0;
                preg_match_all("/[A-Za-z'-]+/", $nword, $words); // Find words in the text that is ('nword')
                foreach ($words[0] as $word)
                {
                  if (!array_key_exists($word, $output))
                        $output[$word] = 0; // initializer
                        $output[$word]++;    // Every time we find this word, we add 1 to the count 
                } 
                foreach ($output as $value)
                {
                    if ($value == 1)
                        $counter++; 
                }
                   return $counter;
        } 
      //This function returns the number of word(s) used more than once
        function words_used_morethan_once($text)
        {
                $nword = strtolower($text);
                $output = $words = array();
                $Ncounter = 0;
                preg_match_all("/[A-Za-z'-]+/", $nword, $words); // Find words in the text that is ('nword')
                foreach ($words[0] as $word)
                {
                  if (!array_key_exists($word, $output))
                        $output[$word] = 0; // initializer
                        $output[$word]++;    // Every time we find this word, we add 1 to the count 
                } 
                foreach ($output as $value) 
                {
                    if (!($value == 1))
                        $Ncounter++; 
                }
                  return $Ncounter;
        }
      ?><!--Functions that processes the text ends here-->

      <!--Chart holder starts here-->
      <div class="chartholder">
        <div class="col-md 6">
          <div class="well">
            <?php 

            //Form validation starts here
                if(isset($_POST['text']) && isset($_POST['submit'])) 
                {
                  $submit = $_POST['submit'];
                  $text = $_POST['text'];
                  if(!empty($text) && !empty($submit))
                  {
                  $result_array = array();
                    echo "The number of words in the text are: ".get_num_of_words($text)."<br><br>";
                    echo "The number of letters in the text are: ".get_num_of_Letters($text)."<br><br>";
                    echo "The number of symbols in the text are: " .get_num_of_symbols($text).  "<br><br>";
                    echo "The number of words that occurred two or more times are: ".words_used_morethan_once($text)."<br><br>";
                    echo "The number of letters used three or more times are: ".get_three_OrMore_Letters($text)."<br><br>";
                    echo "The number of words that occurred once are: ".num_of_words_usedOnce($text);
                    $result_array = [get_num_of_words($text), get_num_of_Letters($text), get_num_of_symbols($text), words_used_morethan_once($text), get_three_OrMore_Letters($text), num_of_words_usedOnce($text)];
                    $result_final = implode(",", $result_array);
                  }
                  //catch exception
                  else {
                    $result_array = array();
                    echo "The number of words used in the text is:  0 <br><br>";
                    echo "The number of letters used in the text is:  0 <br><br>";
                    echo "The number of symbols that occurred in the text is:  0 <br><br>";
                    echo "The number of words that occurred two or more times is:  0 <br><br>";
                    echo "The number of letters that occurred three or more times is:  0 <br><br>";
                    echo "The number of words that occurred once is:  0";                  
                    $result_array = [0,0,0,0,0,0];
                    $result_final = implode(",", $result_array);
                  }
                }
                  //End of form validation
            ?>
          </div>  
        </div>

        <div id="panel-chartjs-2" class="panel panel-default" style="margin-top:1%;">
          <div class="panel-heading">
             <span class="elipsis">
                <strong>Text Analystic Chart</strong>
              </span>

              <!-- right options -->
              <ul class="options pull-right list-inline">
                <li><a href="#" class="opt panel_colapse" data-toggle="tooltip" title="Colapse" data-placement="bottom"></a></li>
                <li><a href="#" class="opt panel_fullscreen hidden-xs" data-toggle="tooltip" title="Fullscreen" data-placement="bottom"><i class="fa fa-expand"></i></a></li>
                <li><a href="#" class="opt panel_close" data-confirm-title="Confirm" data-confirm-message="Are you sure you want to remove this panel?" data-toggle="tooltip" title="Close" data-placement="bottom"><i class="fa fa-times"></i></a></li>
              </ul>
              <!-- /right options -->
          </div>

          <!-- panel content -->
          <div class="panel-body">
              <canvas class="chartjs fullwidth height-400" id="barChartCanvas" width="547" height="300"></canvas>
          </div>
          <!-- /panel content -->

        </div>

      </div><!--Chart holder ends here-->

    </div><!--Main holder ends here-->

    <!-- JAVASCRIPT FILES -->
    <script type="text/javascript"> var plugin_path = 'assets/plugins/';</script>
    <script type="text/javascript" src="assets/plugins/jquery/jquery-2.1.4.min.js"></script>
    <script type="text/javascript" src="assets/js/app.js"></script>
          <!-- PAGE LEVEL SCRIPTS -->
        <script type="text/javascript">
          loadScript(plugin_path + 'chart.chartjs/Chart.min.js', function() 
          {
            var barChartCanvas = 
            {
              labels : ["No of Words","No of Letters","No of Symbols","Words more than Once","Letter freq above '3' ","Words used Once"],
              datasets : [
                            {
                              fillColor : "rgba(47,196,233,0.5)",
                              strokeColor : "rgba(220,220,220,0.8)",
                              highlightFill: "rgba(220,220,220,0.75)",
                              highlightStroke: "rgba(220,220,220,1)",
                              data : [<?php echo $result_final;?>]
                            }
                         ]
            };
            // barChartCanvas
            var ctx = document.getElementById("barChartCanvas").getContext("2d");
            new Chart(ctx).Bar(barChartCanvas);
          });
        </script> 
  </body>
</html>